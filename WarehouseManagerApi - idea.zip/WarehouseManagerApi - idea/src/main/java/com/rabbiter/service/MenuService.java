package com.rabbiter.service;

import com.rabbiter.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author rabbiter
 * @since 2023-01-03
 */
public interface MenuService extends IService<Menu> {

}
